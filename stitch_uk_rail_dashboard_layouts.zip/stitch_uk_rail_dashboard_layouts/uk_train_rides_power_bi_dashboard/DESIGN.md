---
name: Midnight Network Analytics
colors:
  surface: '#10131a'
  surface-dim: '#10131a'
  surface-bright: '#363941'
  surface-container-lowest: '#0b0e15'
  surface-container-low: '#191b23'
  surface-container: '#1d2027'
  surface-container-high: '#272a31'
  surface-container-highest: '#32353d'
  on-surface: '#e1e2ec'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#e1e2ec'
  inverse-on-surface: '#2d3038'
  outline: '#8c909f'
  outline-variant: '#414754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e69'
  primary-container: '#4c8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#40efb7'
  on-secondary: '#003827'
  secondary-container: '#00d29c'
  on-secondary-container: '#00543d'
  tertiary: '#ffb688'
  on-tertiary: '#512400'
  tertiary-container: '#e2720c'
  on-tertiary-container: '#471e00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004494'
  secondary-fixed: '#54fdc4'
  secondary-fixed-dim: '#27e0a9'
  on-secondary-fixed: '#002116'
  on-secondary-fixed-variant: '#00513b'
  tertiary-fixed: '#ffdbc7'
  tertiary-fixed-dim: '#ffb688'
  on-tertiary-fixed: '#311300'
  on-tertiary-fixed-variant: '#733600'
  background: '#10131a'
  on-background: '#e1e2ec'
  surface-variant: '#32353d'
typography:
  dashboard-title:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  kpi-value:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.01em
  section-header:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.01em
  body-main:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-metadata:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: '1.4'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-page: 32px
  gap-default: 24px
  gap-compact: 16px
  padding-card: 20px
  header-height: 80px
---

## Brand & Style
The brand identity is centered on "Executive Intelligence"—a sophisticated, high-tech aesthetic tailored for infrastructure and rail analytics. It evokes feelings of precision, deep-focus, and futuristic network management.

The design style is **Glassmorphism mixed with Modern Corporate**. It utilizes a "Midnight" backdrop with translucent, glass-like containers (`surface-slate-glass`) that feature subtle backdrop blurs and colored top-accent borders. This creates a sense of depth and hierarchy without relying on traditional skeuomorphism. The atmosphere is professional yet cutting-edge, using dark themes to reduce eye strain for long-term monitoring and analysis.

## Colors
The palette is built on a deep navy and charcoal foundation to maintain high legibility and a premium "command center" feel.

- **Primary & Secondary**: Used for functional highlights and brand reinforcement.
- **Surface & Background**: A layered approach using `background-midnight` for the base and `surface-slate-glass` for elevated interactive modules.
- **Semantic Accents**: A vibrant spectrum of functional colors (Demand: Purple, Revenue: Teal, Alert: Rose) provides immediate visual categorization for complex data sets. 
- **Borders**: Highly subtle navy-toned borders (`border-subtle`) define shapes without creating visual clutter.

## Typography
The system relies exclusively on **Inter** to achieve a neutral, systematic, and utilitarian feel. It prioritizes information density and clarity.

- **Hierarchy**: Strong weight contrasts (700 for values, 400 for metadata) guide the eye through complex dashboards.
- **Readability**: Tight letter-spacing on large headings provides a compact, modern look, while increased line-height on body text ensures legibility against dark backgrounds.
- **Labels**: Small-cap or secondary-colored labels help categorize data without competing with primary metrics.

## Layout & Spacing
The layout utilizes a **Fixed Sidebar / Fluid Content** model with a distinct vertical hierarchy.

- **Grid**: A multi-column structure (typically a 1/3 to 2/3 split) allows for a mix of narrow KPI lists and wide analytical visualizations.
- **Rhythm**: A 8px base unit is used, with a default gap of 24px between major modules to provide "breathing room" amidst high-density data.
- **Density**: Cards use generous internal padding (20px) to ensure content does not feel cramped within the glass surfaces.

## Elevation & Depth
Depth is communicated through **Translucency and Tonal Layering** rather than heavy shadows.

- **Glassmorphism**: Primary containers use an 85% opacity fill with a backdrop blur to separate them from the background image/pattern.
- **Shadows**: Low-intensity, diffused ambient shadows (`0 4px 20px rgba(0,0,0,0.2)`) are used to lift cards slightly off the background.
- **Accents**: 1px top-aligned "energy lines" in accent colors (e.g., `accent-demand`) indicate the category or status of a specific module, serving as a functional "elevation" marker.

## Shapes
The shape language is **Softly Rounded**, striking a balance between technical precision and modern approachability.

- **Cards**: Use an `xl` (12px or 0.75rem) corner radius for a friendly, modern container feel.
- **Interactive Elements**: Buttons and inputs follow a `lg` (8px or 0.5rem) radius.
- **Status Indicators**: Use pill-shaped (full) rounding to distinguish them from structural elements.

## Components
### Cards
Glass-morphic surfaces with a 1px `border-subtle` and a 4px colored top-border highlight. They should appear semi-transparent over the background.

### Buttons
Primary buttons should use the `accent-executive` blue with white text. Secondary buttons should use `border-subtle` with a ghost background and `text-secondary`.

### KPI Modules
Feature a large `kpi-value` headline, a `section-header` label, and a small trend indicator (using `accent-revenue` for positive or `accent-alert` for negative).

### Navigation
- **Sidebar**: Dark, low-contrast background with active states highlighted by a left-border and `primary-fixed` text color.
- **Top Bar**: Minimalist and high-clearance (80px height) to provide context and global actions.

### Data Visualization
Charts should use the full accent palette (`accent-demand`, `accent-revenue`, etc.) against the `surface-slate-glass` cards, ensuring high contrast for line work and data points.